<!-- Javascript files -->
<!-- jQuery -->
<script src="<?php echo e(asset('public/assets/js/jquery.js')); ?>"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>
<!-- WayPoints JS -->
<script src="<?php echo e(asset('public/assets/js/waypoints.min.js')); ?>"></script>
<!-- Include js plugin -->
<script src="<?php echo e(asset('public/assets/js/owl.carousel.min.js')); ?>"></script>
<!-- One Page Nav -->
<script src="<?php echo e(asset('public/assets/js/jquery.nav.js')); ?>"></script>
<!-- Respond JS for IE8 -->
<script src="<?php echo e(asset('public/assets/js/respond.min.js')); ?>"></script>
<!-- HTML5 Support for IE -->
<script src="<?php echo e(asset('public/assets/js/html5shiv.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('public/assets/js/custom.js')); ?>"></script>
<?php echo $__env->yieldPushContent('script'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH D:\xampp\htdocs\demoproject\resources\views/includes/script.blade.php ENDPATH**/ ?>