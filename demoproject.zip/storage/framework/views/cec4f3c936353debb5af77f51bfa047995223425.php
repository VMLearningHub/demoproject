

<?php $__env->startSection('content'); ?>
    <div class="featured pad" id="featuredalbum">
        <div class="container">
            <!-- default heading -->
            <div class="default-heading">
                <!-- heading -->
                <h2>Featured Album</h2>
            </div>
            <!-- featured album elements -->
            <div class="featured-element">
                <div class="row">
                    <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-sm-6">

                            <!-- featured item -->
                            <div class="featured-item ">
                                <a href="<?php echo e(route('view-album', encrypt($album->id))); ?>">
                                    <!-- image container -->
                                    <div class="figure">
                                        <!-- image -->
                                        <?php
                                            if (File::exists('public/assets/img/album/' . $album->image)) {
                                                $cimage = $album->image;
                                            } else {
                                                $cimage = 'default.png';
                                            }
                                            
                                        ?>
                                        <img class="img-responsive" src="<?php echo e(asset('public/assets/img/album/' . $cimage)); ?>"
                                            alt="" />
                                        <!-- paragraph -->

                                    </div>
                                </a>
                                <!-- featured information -->
                                <div class="featured-item-info">
                                    <!-- featured title -->
                                    <h4><?php echo e($album->name ?? ''); ?></h4>
                                    <!-- horizontal line -->
                                    <hr />
                                    <!-- some responce from social medial or web likes -->
                                    <p><?php echo e($album->artist ?? ''); ?></p>
                                </div>
                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
            <div class="container text-center">
                <?php echo e($albums->links()); ?>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\demoproject\resources\views/index.blade.php ENDPATH**/ ?>