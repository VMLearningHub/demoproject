<!-- Javascript files -->
<!-- jQuery -->
<script src="{{ asset('public/assets/js/jquery.js') }}"></script>
<!-- Bootstrap JS -->
<script src="{{ asset('public/assets/js/bootstrap.min.js') }}"></script>
<!-- WayPoints JS -->
<script src="{{ asset('public/assets/js/waypoints.min.js') }}"></script>
<!-- Include js plugin -->
<script src="{{ asset('public/assets/js/owl.carousel.min.js') }}"></script>
<!-- One Page Nav -->
<script src="{{ asset('public/assets/js/jquery.nav.js') }}"></script>
<!-- Respond JS for IE8 -->
<script src="{{ asset('public/assets/js/respond.min.js') }}"></script>
<!-- HTML5 Support for IE -->
<script src="{{ asset('public/assets/js/html5shiv.js') }}"></script>
<!-- Custom JS -->
<script src="{{ asset('public/assets/js/custom.js') }}"></script>
@stack('script')
@stack('scripts')